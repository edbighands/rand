package domain.models;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the ROOM_SLOT_AVLBLTY_LKP database table.
 * 
 */
@Embeddable
public class RoomSlotAvlbltyLkpPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="ROOM_CAT_ID")
	private int roomCatId;

	@Column(name="SLOT_ID")
	private int slotId;

	public RoomSlotAvlbltyLkpPK() {
	}
	public int getRoomCatId() {
		return this.roomCatId;
	}
	public void setRoomCatId(int roomCatId) {
		this.roomCatId = roomCatId;
	}
	public int getSlotId() {
		return this.slotId;
	}
	public void setSlotId(int slotId) {
		this.slotId = slotId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof RoomSlotAvlbltyLkpPK)) {
			return false;
		}
		RoomSlotAvlbltyLkpPK castOther = (RoomSlotAvlbltyLkpPK)other;
		return 
			(this.roomCatId == castOther.roomCatId)
			&& (this.slotId == castOther.slotId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.roomCatId;
		hash = hash * prime + this.slotId;
		
		return hash;
	}
}