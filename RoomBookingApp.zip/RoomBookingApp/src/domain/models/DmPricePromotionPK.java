package domain.models;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the DM_PRICE_PROMOTIONS database table.
 * 
 */
@Embeddable
public class DmPricePromotionPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="PROMO_ID")
	private int promoId;

	@Column(name="ROOM_PROMO_ID")
	private int roomPromoId;

	public DmPricePromotionPK() {
	}
	public int getPromoId() {
		return this.promoId;
	}
	public void setPromoId(int promoId) {
		this.promoId = promoId;
	}
	public int getRoomPromoId() {
		return this.roomPromoId;
	}
	public void setRoomPromoId(int roomPromoId) {
		this.roomPromoId = roomPromoId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof DmPricePromotionPK)) {
			return false;
		}
		DmPricePromotionPK castOther = (DmPricePromotionPK)other;
		return 
			(this.promoId == castOther.promoId)
			&& (this.roomPromoId == castOther.roomPromoId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.promoId;
		hash = hash * prime + this.roomPromoId;
		
		return hash;
	}
}