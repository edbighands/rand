package my.misc.beans;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;

import domain.models.VRoomsForgedPK;

public class SelectedRoomTO {

	

	

	
	
	private String amenities;


	private String isDuplex;


	private String isHillView;

	
	private String isSouthFacing;

	
	private BigDecimal priceWithoutOffers;

	
	private String reservationTime;


	private String reservationType;

	


	private String roomSize;

	
	private String roomType;
	
	private int slotsId;
	
	private int roomCatId;
	

	

	public String getAmenities() {
		return this.amenities;
	}

	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}

	public String getIsDuplex() {
		return this.isDuplex;
	}

	public void setIsDuplex(String isDuplex) {
		this.isDuplex = isDuplex;
	}

	public String getIsHillView() {
		return this.isHillView;
	}

	public void setIsHillView(String isHillView) {
		this.isHillView = isHillView;
	}

	public String getIsSouthFacing() {
		return this.isSouthFacing;
	}

	public void setIsSouthFacing(String isSouthFacing) {
		this.isSouthFacing = isSouthFacing;
	}

	public BigDecimal getPriceWithoutOffers() {
		return this.priceWithoutOffers;
	}

	public void setPriceWithoutOffers(BigDecimal priceWithoutOffers) {
		this.priceWithoutOffers = priceWithoutOffers;
	}

	public String getReservationTime() {
		return this.reservationTime;
	}

	public void setReservationTime(String reservationTime) {
		this.reservationTime = reservationTime;
	}

	public String getReservationType() {
		return this.reservationType;
	}

	public void setReservationType(String reservationType) {
		this.reservationType = reservationType;
	}

	
	

	public String getRoomSize() {
		return this.roomSize;
	}

	public void setRoomSize(String roomSize) {
		this.roomSize = roomSize;
	}

	public String getRoomType() {
		return this.roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public int getSlotsId() {
		return slotsId;
	}

	public void setSlotsId(int slotsId) {
		this.slotsId = slotsId;
	}

	public int getRoomCatId() {
		return roomCatId;
	}

	public void setRoomCatId(int roomCatId) {
		this.roomCatId = roomCatId;
	}





}
