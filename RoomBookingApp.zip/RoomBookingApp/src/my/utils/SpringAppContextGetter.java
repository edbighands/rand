package my.utils;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class SpringAppContextGetter implements ApplicationContextAware  {
private static	ApplicationContext context;
	
	public static Object getBeanFromContextByName(String beanName) {
		return context.getBean(beanName);
	}
	@Override
	public void setApplicationContext(ApplicationContext context)
			throws BeansException {
		SpringAppContextGetter.context=context;
	}
	
	
	
} 