package my.ruleengine;

import java.math.BigDecimal;

import my.misc.beans.PromotionMapHolder;

class RoomNotFillingPromoDecorator extends PricePromoDecorator {
	public static final int PROMO_ID=3;
	private BigDecimal roomNotFilingPromoDisc;
	
	@Override
	protected BigDecimal getPrice() {
		return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.roomNotFilingPromoDisc);
	}

	BigDecimal getSmallRoomPromoDisc() {
		return roomNotFilingPromoDisc;
	}

	void setSmallRoomPromoDisc(BigDecimal roomNotFilingPromoDisc) {
		this.roomNotFilingPromoDisc = roomNotFilingPromoDisc;
	}

	RoomNotFillingPromoDecorator(BigDecimal roomNotFilingPromoDisc) {
		this.roomNotFilingPromoDisc=roomNotFilingPromoDisc;
	}

	RoomNotFillingPromoDecorator(AbstractPriceBean priceBean) {
		this(PromotionMapHolder.refreshAndGet(PROMO_ID));
	
	
	this.baseSpecialPriceDecoretee=priceBean;
	}
	
	
}

