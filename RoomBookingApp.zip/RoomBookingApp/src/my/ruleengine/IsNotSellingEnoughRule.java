package my.ruleengine;

class IsNotSellingEnoughRule extends PromotionDiscountRulesComposite {

private static final Integer numThresholdToCOnsiderNotSellingEnough=3;

	@Override
	void print() {
	
		System.out.println("IsNotSellingEnoughRule");

	}

	@Override
	boolean evaluate(DecisionPointVO decisionPointVO) {
		if(numThresholdToCOnsiderNotSellingEnough>decisionPointVO.getNumOfSuchRoomsAvailable())
			return true;
		
		return false;
	}

	@Override
	public void accept(IRuleVisitor visitor) {
		visitor.visit(this);
		
	}

}
