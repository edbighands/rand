package my.ruleengine;

class IsSmallRoomRule extends PromotionDiscountRulesComposite {

	@Override
	boolean evaluate(DecisionPointVO decisionPointVO) {
		switch(decisionPointVO.getSelectedRoomBean().getRoomType())
		{
		
		case ECONOMY: return true;
		
		default : return false;
		}
	}

	@Override
	void print() {

		System.out.println("IsSmallRoomRule");

	}
	@Override
	public void accept(IRuleVisitor visitor) {
		visitor.visit(this);
		
	}

}
