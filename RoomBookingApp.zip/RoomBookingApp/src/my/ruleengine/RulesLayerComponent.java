package my.ruleengine;

import java.util.List;

abstract class RulesLayerComponent implements IVisitableDataBean{

	  void add(RulesLayerComponent catalogComponent){
	        throw new UnsupportedOperationException("Cannot add item to catalog.");
	    }
	 
	     void remove(RulesLayerComponent catalogComponent)
	     {  throw new UnsupportedOperationException("Cannot return name.");
	    	 
	     }
	 
	      String getpPromoAppliedName(){
	        throw new UnsupportedOperationException("Cannot return name.");
	    }
	 
	    abstract  boolean evaluate(DecisionPointVO decisionPointVO);
	 
	 
	     abstract   void  print();
	     
	     abstract List<RulesLayerComponent> getAllDisjointLayers();
	
}
