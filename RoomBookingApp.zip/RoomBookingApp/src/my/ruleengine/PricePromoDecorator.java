package my.ruleengine;

import java.math.BigDecimal;

abstract class PricePromoDecorator extends AbstractPriceBean {

	protected AbstractPriceBean baseSpecialPriceDecoretee;
	
	


	@Override
	protected abstract BigDecimal getPrice() ;

	@Override
	protected void setPrice(BigDecimal price) throws NoSuchMethodError {
		throw new NoSuchMethodError("Unimplemented");

	}

}
