package my.ruleengine;

import javax.sql.DataSource;

import my.DAO.RuleEngineHelperDAO;

public abstract class AbstractBuilder {

	 abstract  AbstractBuilder create(Object arg);
	 abstract  AbstractBuilder cloneDeep();
	 abstract   Object build();
	 abstract  AbstractBuilder fetchFromDB(RuleEngineHelperDAO RuleEngineHelperDAO);
	 abstract  AbstractBuilder setToProduce(Object param);
}
