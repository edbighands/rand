package my.ruleengine;

import java.math.BigDecimal;

import my.misc.beans.PromotionMapHolder;

class FestivalPromoDecorator extends PricePromoDecorator {
public static final int PROMO_ID=1;
	private BigDecimal festivalDiscount;
	
	 BigDecimal getFestivalDiscount() {
		return festivalDiscount;
	}

	 void setFestivalDiscount(BigDecimal festivalDiscount) {
		this.festivalDiscount = festivalDiscount;
	}
	 
	 

	FestivalPromoDecorator(AbstractPriceBean priceBean) {
		
		this(PromotionMapHolder.refreshAndGet(PROMO_ID));
		
		
		this.baseSpecialPriceDecoretee=priceBean;
	}

	public FestivalPromoDecorator(BigDecimal festivalDiscount) {
		this.festivalDiscount=festivalDiscount;
	}

	@Override
	protected BigDecimal getPrice() {
	return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.festivalDiscount);
	}

}
