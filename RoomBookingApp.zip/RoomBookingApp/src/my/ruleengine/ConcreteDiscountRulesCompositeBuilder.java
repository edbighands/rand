package my.ruleengine;

import my.DAO.RuleEngineHelperDAO;

public class ConcreteDiscountRulesCompositeBuilder extends AbstractBuilder{

	private RulesLayerComponent rulesLayerComponent;
	
	@Override
	AbstractBuilder create(Object arg) {
		 this.rulesLayerComponent = new PromotionDiscountRulesComposite();
		IsFestiveSeasonRule isFestiveSeasonRule=	new IsFestiveSeasonRule();
		IsNotSellingEnoughRule isNotSellingEnoughRule = new IsNotSellingEnoughRule();
		IsPremiumRoomRule isPremiumRoomRule = new IsPremiumRoomRule();
		IsSmallRoomRule isSmallRoomRule = new IsSmallRoomRule();
		
		rulesLayerComponent.add(isFestiveSeasonRule);
		rulesLayerComponent.add(isNotSellingEnoughRule);
		rulesLayerComponent.add(isPremiumRoomRule);
		rulesLayerComponent.add(isSmallRoomRule);
		return this;
	}

	@Override
	AbstractBuilder cloneDeep() {
		throw new UnsupportedOperationException("Cannot cloneDeep().");
	}

	@Override
	RulesLayerComponent build() {
		return this.rulesLayerComponent;
	}

	@Override
	AbstractBuilder fetchFromDB(RuleEngineHelperDAO RuleEngineHelperDAO) {
		throw new UnsupportedOperationException("Cannot fetchFromDB().");
	}

	@Override
	AbstractBuilder setToProduce(Object param) {
		throw new UnsupportedOperationException("Cannot setToProduce().");
	}

	
	
	
}
