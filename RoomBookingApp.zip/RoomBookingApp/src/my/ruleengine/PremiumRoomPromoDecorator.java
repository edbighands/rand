package my.ruleengine;

import java.math.BigDecimal;

import my.misc.beans.PromotionMapHolder;

class PremiumRoomPromoDecorator extends PricePromoDecorator {
	public static final int PROMO_ID=2;
	private BigDecimal premiumPromoDisc;
	
	@Override
	protected BigDecimal getPrice() {
		return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.premiumPromoDisc);
	}

	BigDecimal getPremiumPromoDisc() {
		return premiumPromoDisc;
	}

	void setPremiumPromoDisc(BigDecimal premiumPromoDisc) {
		this.premiumPromoDisc = premiumPromoDisc;
	}

	PremiumRoomPromoDecorator(BigDecimal premiumPromoDisc) {
		this.premiumPromoDisc=premiumPromoDisc;
	}


	PremiumRoomPromoDecorator(AbstractPriceBean priceBean) {
		this(PromotionMapHolder.refreshAndGet(PROMO_ID));
		
		
		this.baseSpecialPriceDecoretee=priceBean;
	}	
	
	
}
