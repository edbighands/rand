package my.service;

import java.util.Date;
import java.util.List;

import javax.persistence.OptimisticLockException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import domain.models.RoomReservationOltp;
import domain.models.RoomSlotAvlbltyLkp;
import domain.models.UserRatingTran;
import domain.models.VRoomsDisplay;
import my.DAO.RuleEngineHelperDAO;
import my.DAO.TransactionalOLTPDAO;
import my.DAO.ViewableElementsReadOnlyDAO;
import my.misc.beans.SelectedRoomTO;

import my.ruleengine.ConcreteDecisionPointVOBuilder;
import my.ruleengine.ConcreteDiscountRulesCompositeBuilder;
import my.ruleengine.ConcretePriceBeanBuilder;
import my.ruleengine.PriceRuleEngineDirector;
import my.utils.SpringAppContextGetter;

@Service
@Transactional(readOnly = true)
public class CentralWaitingRoomService {

	@Autowired
	private RuleEngineHelperDAO ruleEngineHelperDAO;
	
	@Autowired
	private ViewableElementsReadOnlyDAO viewableElementsReadOnlyDAO;
	
	@Autowired
	private TransactionalOLTPDAO transactionalOLTPDAO;
	
	public List<VRoomsDisplay> viewRoomsAndSlots()
	{
		
		return viewableElementsReadOnlyDAO.getVRoomsDisplayList();
	}
	
	public List<UserRatingTran> viewRatingsOfRooms()
	{
		return viewableElementsReadOnlyDAO.getUserRatingTranList();
	}
	
	public SelectedRoomTO roomSelectedNowFetchDynamicPrice(SelectedRoomTO selectedRoomTO )
	{
		
		PriceRuleEngineDirector priceRuleEngineDirector=	(PriceRuleEngineDirector)SpringAppContextGetter.getBeanFromContextByName("priceRuleEngineDirector");
		priceRuleEngineDirector.setSelectedRoomTO(selectedRoomTO);
		priceRuleEngineDirector.setRuleEngineHelperDAO(ruleEngineHelperDAO);
		
		priceRuleEngineDirector.setAbstractBuilderStateMachineAndRetrivePrice(new ConcreteDecisionPointVOBuilder());
		priceRuleEngineDirector.setAbstractBuilderStateMachineAndRetrivePrice(new ConcretePriceBeanBuilder());
		selectedRoomTO =	priceRuleEngineDirector.setAbstractBuilderStateMachineAndRetrivePrice(new ConcreteDiscountRulesCompositeBuilder());
		
		return selectedRoomTO;
		
	}
	@Transactional(readOnly = false)
	public Integer bookRoom(SelectedRoomTO selectedRoomTO)
	{
		
		
		RoomSlotAvlbltyLkp roomSlotAvlbltyLkp =transactionalOLTPDAO.lookForAvailability(selectedRoomTO);
		
		if(roomSlotAvlbltyLkp.getAvailabilityCount()>0)
		{
			RoomReservationOltp roomReservationOltp = new RoomReservationOltp();
			roomReservationOltp.setFinalPrice(selectedRoomTO.getPriceWithoutOffers());
			roomReservationOltp.setRoomCatId(selectedRoomTO.getRoomCatId());
			roomReservationOltp.setSlotsId(selectedRoomTO.getSlotsId());
			roomReservationOltp.setReservationDate(new java.sql.Timestamp(new Date().getTime()));
			
			do {
				transactionalOLTPDAO.detachhEntityForCleaningL1(roomSlotAvlbltyLkp);
				roomSlotAvlbltyLkp.setAvailabilityCount(roomSlotAvlbltyLkp.getAvailabilityCount()-1);
				//The above gives some random clean time for less conflicts before entity becomes managed again
			try {
				
				
				roomSlotAvlbltyLkp=	transactionalOLTPDAO.changeAvailability(roomSlotAvlbltyLkp);
				
				transactionalOLTPDAO.confirmReservation(roomReservationOltp);
			}catch (OptimisticLockException oe) {
				transactionalOLTPDAO.refreshAfterOLE(roomSlotAvlbltyLkp);
			}
			
			}while(roomSlotAvlbltyLkp.getAvailabilityCount()>0);
			throw new RuntimeException("No Rooms Available For the Given SLOT");
		}
		else
		{
			throw new RuntimeException("No Rooms Available For the Given SLOT");
		}
		
	}
	
}
