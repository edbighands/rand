package my.DAO;

import java.sql.Types;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import domain.models.DmPricePromotion;


public class RuleEngineHelperDAO {

	private JdbcTemplate jdbcTemplate;
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Autowired
	public void jdbcTemplate(DataSource dataSource)
	{
		this.jdbcTemplate= new JdbcTemplate(dataSource);
	}
	
	public Integer getNumberOfAvailableRoomsByRoomAndSlot(Integer roomCatID, Integer slotID)
	{
		
	return (Integer)	jdbcTemplate.queryForObject("SELECT AVAILABILITY_COUNT from ROOM_SLOT_AVLBLTY_LKP where ROOM_CAT_ID = ? and SLOT_ID = ?", new Object[] {roomCatID,slotID}, new int[] {Types.INTEGER,Types.INTEGER},Integer.class);
	
		
	}
	
	
	public List<DmPricePromotion> getDmPricePromotionList()	{

		 TypedQuery<DmPricePromotion> query = entityManager.createNamedQuery("DmPricePromotion.findAll", DmPricePromotion.class);

		return query.getResultList();


	}
	
}
