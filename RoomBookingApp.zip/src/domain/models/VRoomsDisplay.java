package domain.models;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the V_ROOMS_DISPLAY database table.
 * 
 */
@Entity
@Table(name="V_ROOMS_DISPLAY")
@NamedQuery(name="VRoomsDisplay.findAll", query="SELECT v FROM VRoomsDisplay v")
public class VRoomsDisplay implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private VRoomsForgedPK vRoomsForgedPK;
	
	@Column(insertable=false, updatable=false)
	private String amenities;

	@Column(name="IS_DUPLEX", insertable=false, updatable=false)
	private String isDuplex;

	@Column(name="IS_HILL_VIEW", insertable=false, updatable=false)
	private String isHillView;

	@Column(name="IS_SOUTH_FACING", insertable=false, updatable=false)
	private String isSouthFacing;

	@Column(name="PRICE_WITHOUT_OFFERS", insertable=false, updatable=false)
	private BigDecimal priceWithoutOffers;

	@Column(name="RESERVATION_TIME", insertable=false, updatable=false)
	private String reservationTime;

	@Column(name="RESERVATION_TYPE", insertable=false, updatable=false)
	private String reservationType;

	

	@Column(name="ROOM_SIZE", insertable=false, updatable=false)
	private String roomSize;

	@Column(name="ROOM_TYPE", insertable=false, updatable=false)
	private String roomType;

	

	public VRoomsDisplay() {
	}

	public String getAmenities() {
		return this.amenities;
	}

	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}

	public String getIsDuplex() {
		return this.isDuplex;
	}

	public void setIsDuplex(String isDuplex) {
		this.isDuplex = isDuplex;
	}

	public String getIsHillView() {
		return this.isHillView;
	}

	public void setIsHillView(String isHillView) {
		this.isHillView = isHillView;
	}

	public String getIsSouthFacing() {
		return this.isSouthFacing;
	}

	public void setIsSouthFacing(String isSouthFacing) {
		this.isSouthFacing = isSouthFacing;
	}

	public BigDecimal getPriceWithoutOffers() {
		return this.priceWithoutOffers;
	}

	public void setPriceWithoutOffers(BigDecimal priceWithoutOffers) {
		this.priceWithoutOffers = priceWithoutOffers;
	}

	public String getReservationTime() {
		return this.reservationTime;
	}

	public void setReservationTime(String reservationTime) {
		this.reservationTime = reservationTime;
	}

	public String getReservationType() {
		return this.reservationType;
	}

	public void setReservationType(String reservationType) {
		this.reservationType = reservationType;
	}

	
	

	public String getRoomSize() {
		return this.roomSize;
	}

	public void setRoomSize(String roomSize) {
		this.roomSize = roomSize;
	}

	public String getRoomType() {
		return this.roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public VRoomsForgedPK getvRoomsForgedPK() {
		return vRoomsForgedPK;
	}

	public void setvRoomsForgedPK(VRoomsForgedPK vRoomsForgedPK) {
		this.vRoomsForgedPK = vRoomsForgedPK;
	}



}