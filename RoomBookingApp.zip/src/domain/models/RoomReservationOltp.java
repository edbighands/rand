package domain.models;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Timestamp;


/**
 * The persistent class for the ROOM_RESERVATION_OLTP database table.
 * 
 */
@Entity
@Table(name="ROOM_RESERVATION_OLTP")
@NamedQuery(name="RoomReservationOltp.findAll", query="SELECT r FROM RoomReservationOltp r")
public class RoomReservationOltp implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ROOM_RESERVATION_OLTP_RESERVATIONID_GENERATOR", sequenceName="SEQ_ROOM_RESERVATION")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ROOM_RESERVATION_OLTP_RESERVATIONID_GENERATOR")
	@Column(name="RESERVATION_ID")
	private int reservationId;

	@Column(name="FINAL_PRICE")
	private BigDecimal finalPrice;

	@Column(name="PROMO_APPLIED")
	private String promoApplied;

	@Column(name="RESERVATION_DATE")
	private Timestamp reservationDate;

	@Column(name="ROOM_CAT_ID")
	private int roomCatId;

	@Column(name="SLOTS_ID")
	private int slotsId;

	@Column(name="USER_ID")
	private int userId;

	public RoomReservationOltp() {
	}

	public int getReservationId() {
		return this.reservationId;
	}

	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}

	public BigDecimal getFinalPrice() {
		return this.finalPrice;
	}

	public void setFinalPrice(BigDecimal finalPrice) {
		this.finalPrice = finalPrice;
	}

	public String getPromoApplied() {
		return this.promoApplied;
	}

	public void setPromoApplied(String promoApplied) {
		this.promoApplied = promoApplied;
	}

	public Timestamp getReservationDate() {
		return this.reservationDate;
	}

	public void setReservationDate(Timestamp reservationDate) {
		this.reservationDate = reservationDate;
	}

	public int getRoomCatId() {
		return this.roomCatId;
	}

	public void setRoomCatId(int roomCatId) {
		this.roomCatId = roomCatId;
	}

	public int getSlotsId() {
		return this.slotsId;
	}

	public void setSlotsId(int slotsId) {
		this.slotsId = slotsId;
	}

	public int getUserId() {
		return this.userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}