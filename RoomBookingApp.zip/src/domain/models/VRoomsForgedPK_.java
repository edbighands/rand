package domain.models;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-10T10:18:00.356+0530")
@StaticMetamodel(VRoomsForgedPK.class)
public class VRoomsForgedPK_ {
	public static volatile SingularAttribute<VRoomsForgedPK, Integer> slotsId;
	public static volatile SingularAttribute<VRoomsForgedPK, Integer> roomCatId;
}
