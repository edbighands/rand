package domain.models;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the DM_PRICE_PROMOTIONS database table.
 * 
 */
@Entity
@Table(name="DM_PRICE_PROMOTIONS")
@NamedQuery(name="DmPricePromotion.findAll", query="SELECT d FROM DmPricePromotion d")
public class DmPricePromotion implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private DmPricePromotionPK id;

	@Column(name="PROMO_CATEGORY")
	private String promoCategory;

	@Column(name="PROMO_DISC")
	private BigDecimal promoDisc;

	public DmPricePromotion() {
	}

	public DmPricePromotionPK getId() {
		return this.id;
	}

	public void setId(DmPricePromotionPK id) {
		this.id = id;
	}

	public String getPromoCategory() {
		return this.promoCategory;
	}

	public void setPromoCategory(String promoCategory) {
		this.promoCategory = promoCategory;
	}

	public BigDecimal getPromoDisc() {
		return this.promoDisc;
	}

	public void setPromoDisc(BigDecimal promoDisc) {
		this.promoDisc = promoDisc;
	}

}