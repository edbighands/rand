package domain.models;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the ROOM_SLOT_AVLBLTY_LKP database table.
 * 
 */
@Entity
@Table(name="ROOM_SLOT_AVLBLTY_LKP")
@NamedQuery(name="RoomSlotAvlbltyLkp.findAll", query="SELECT r FROM RoomSlotAvlbltyLkp r")
public class RoomSlotAvlbltyLkp implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RoomSlotAvlbltyLkpPK id;

	@Column(name="AVAILABILITY_COUNT")
	private int availabilityCount;
	
@Version
	@Column(name="VERSION_ID")
	private Long versionId;

	public RoomSlotAvlbltyLkp() {
	}

	public RoomSlotAvlbltyLkpPK getId() {
		return this.id;
	}

	public void setId(RoomSlotAvlbltyLkpPK id) {
		this.id = id;
	}

	public int getAvailabilityCount() {
		return this.availabilityCount;
	}

	public void setAvailabilityCount(int availabilityCount) {
		this.availabilityCount = availabilityCount;
	}

	public Long getVersionId() {
		return this.versionId;
	}

	public void setVersionId(Long versionId) {
		this.versionId = versionId;
	}

}