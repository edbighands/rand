package my.ruleengine;

interface IVisitableDataBean {

	 void accept(IRuleVisitor visitor);
}
