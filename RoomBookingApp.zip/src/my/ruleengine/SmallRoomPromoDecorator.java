package my.ruleengine;

import java.math.BigDecimal;

import my.misc.beans.PromotionMapHolder;

class SmallRoomPromoDecorator extends PricePromoDecorator {
	public static final int PROMO_ID=4;
	private BigDecimal smallRoomPromoDisc;
	
	@Override
	protected BigDecimal getPrice() {
		return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.smallRoomPromoDisc);
	}

	BigDecimal getSmallRoomPromoDisc() {
		return smallRoomPromoDisc;
	}

	void setSmallRoomPromoDisc(BigDecimal smallRoomPromoDisc) {
		this.smallRoomPromoDisc = smallRoomPromoDisc;
	}

	SmallRoomPromoDecorator(BigDecimal smallRoomPromoDisc) {
	
		this.smallRoomPromoDisc=smallRoomPromoDisc;
		
	}

SmallRoomPromoDecorator(AbstractPriceBean priceBean) {
	this(PromotionMapHolder.refreshAndGet(PROMO_ID));
	
	
	this.baseSpecialPriceDecoretee=priceBean;
	}
	
	
}
