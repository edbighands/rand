package my.ruleengine;

import java.math.BigDecimal;

abstract class AbstractPriceBean {

	protected BigDecimal price;

	protected abstract BigDecimal getPrice();

	protected abstract void setPrice(BigDecimal price) ;


	
	
	
}
