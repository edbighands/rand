package my.ruleengine;

class IsPremiumRoomRule extends PromotionDiscountRulesComposite {



	@Override
	boolean evaluate(DecisionPointVO decisionPointVO) {
		
		switch(decisionPointVO.getSelectedRoomBean().getRoomType())
		{
		case EXECUTIVE_PREMIUM: return true;
		case CORPORATE: return true;
		case ECONOMY: return false;
		case STANDARD : return false;
		default : return false;
		}
		
	}

	@Override
	void print() {
		System.out.println("IsPremiumRoomRule");

	}
	@Override
	public void accept(IRuleVisitor visitor) {
		visitor.visit(this);
		
	}

}
