package my.ruleengine;

interface IRuleVisitor {
	void visit(RulesLayerComponent rule);
}
