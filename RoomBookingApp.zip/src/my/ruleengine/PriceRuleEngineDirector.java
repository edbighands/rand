package my.ruleengine;

import java.math.BigDecimal;

import my.DAO.RuleEngineHelperDAO;
import my.misc.beans.SelectedRoomTO;

public class PriceRuleEngineDirector {

	private AbstractBuilder abstractBuilder;
private AbstractPriceBean abstractPriceBean;
private DecisionPointVO decisionPointVO;
private RulesLayerComponent rulesLayerComponent;
private SelectedRoomTO selectedRoomTO;
private RuleEngineHelperDAO ruleEngineHelperDAO;


	public PriceRuleEngineDirector(SelectedRoomTO selectedRoomTO,RuleEngineHelperDAO ruleEngineHelperDAO) {
	
	this.selectedRoomTO = selectedRoomTO;
	this.ruleEngineHelperDAO=ruleEngineHelperDAO;
}

	

	public PriceRuleEngineDirector() {
		
	}
	
	





	public void setSelectedRoomTO(SelectedRoomTO selectedRoomTO) {
		this.selectedRoomTO = selectedRoomTO;
	}



	public void setRuleEngineHelperDAO(RuleEngineHelperDAO ruleEngineHelperDAO) {
		this.ruleEngineHelperDAO = ruleEngineHelperDAO;
	}



	public SelectedRoomTO setAbstractBuilderStateMachineAndRetrivePrice(AbstractBuilder abstractBuilder) {
		
		if(this.abstractBuilder==null)
		{
			this.abstractBuilder = abstractBuilder;
			if (abstractBuilder instanceof ConcreteDecisionPointVOBuilder)
			{
				prepareDecisionPointVO(abstractBuilder);
			}
			else
			{
				throw new RuntimeException("The first builder passed should be an instance of ConcreteDecisionPointVOBuilder");
			}
			
		}
		else
		{
		
			this.abstractBuilder = abstractBuilder;
		if(abstractBuilder instanceof ConcretePriceBeanBuilder)
		{
			preparePriceBean(abstractBuilder);
		}
		else if (abstractBuilder instanceof ConcreteDiscountRulesCompositeBuilder)
		{
			prepareRulesLayerComponent(abstractBuilder);
			
		}
		}
		
		
		if((abstractPriceBean!=null)&&(decisionPointVO!=null)&&(rulesLayerComponent!=null))
		{
			System.out.println("RULE ENGINE INIT COMPLETED..NOW EXECUTING...");
			
			dynamicDiscountedPrice();
			
			
			return selectedRoomTO;
		}
		
		return null;
	}


	private void preparePriceBean( AbstractBuilder abstractBuilder)
	{
	this.abstractPriceBean=(AbstractPriceBean)	abstractBuilder.create(null).setToProduce(this.decisionPointVO.getSelectedRoomBean()).build();
	}
	private void prepareDecisionPointVO( AbstractBuilder abstractBuilder)
	{
	this.decisionPointVO=	(DecisionPointVO)abstractBuilder.create(this.selectedRoomTO).fetchFromDB(this.ruleEngineHelperDAO).build();
	}
	private void prepareRulesLayerComponent( AbstractBuilder abstractBuilder)
	{
	this.rulesLayerComponent=(RulesLayerComponent)	abstractBuilder.create(null).build();
	}
	
	private void dynamicDiscountedPrice()
	{
		IRuleVisitor iRuleVisitor = new RuleEvalAndDiscCalVisitor(decisionPointVO,abstractPriceBean);
		
		for(RulesLayerComponent rulesLayerComponent : this.rulesLayerComponent.getAllDisjointLayers())
		{
			
			rulesLayerComponent.accept(iRuleVisitor);
			
			
		}
		
	BigDecimal dynamicDiscPrice=	((RuleEvalAndDiscCalVisitor)iRuleVisitor).getAbstractPriceBean().getPrice();
	
	this.selectedRoomTO.setPriceWithoutOffers(dynamicDiscPrice);
	
	}
	
}
