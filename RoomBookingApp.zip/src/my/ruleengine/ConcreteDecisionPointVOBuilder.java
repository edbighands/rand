package my.ruleengine;



import my.DAO.RuleEngineHelperDAO;
import my.misc.beans.SelectedRoomTO;
import my.ruleengine.SelectedRoomBean.ROOM_RESERVATION_TYPE;
import my.ruleengine.SelectedRoomBean.ROOM_SIZE;
import my.ruleengine.SelectedRoomBean.ROOM_TYPE;

public class ConcreteDecisionPointVOBuilder extends AbstractBuilder{

	private DecisionPointVO decisionPointVO;
	
	@Override
	 AbstractBuilder create(Object arg) {
		SelectedRoomTO selectedRoomTO = (SelectedRoomTO)arg;
		SelectedRoomBean selectedRoomBean = new SelectedRoomBean();
		selectedRoomBean.setIsDuplex(selectedRoomTO.getIsDuplex());
		selectedRoomBean.setIsHillView(selectedRoomTO.getIsHillView());
		selectedRoomBean.setIsSouthFacing(selectedRoomTO.getIsSouthFacing());
		selectedRoomBean.setPriceWithoutOffers(selectedRoomTO.getPriceWithoutOffers());
		selectedRoomBean.setRoomCatId(selectedRoomTO.getRoomCatId());
		selectedRoomBean.setSlotsId(selectedRoomTO.getSlotsId());
		
		if(ROOM_TYPE.ECONOMY.getRoomTypeVal().equals(selectedRoomTO.getRoomType()))
		{
			selectedRoomBean.setRoomType(ROOM_TYPE.ECONOMY);

		}
		else if(ROOM_TYPE.STANDARD.getRoomTypeVal().equals(selectedRoomTO.getRoomType()))
		{
			selectedRoomBean.setRoomType(ROOM_TYPE.STANDARD);

		}
		else	if(ROOM_TYPE.CORPORATE.getRoomTypeVal().equals(selectedRoomTO.getRoomType()))
		{
			selectedRoomBean.setRoomType(ROOM_TYPE.CORPORATE);

		}
		else	if(ROOM_TYPE.EXECUTIVE_PREMIUM.getRoomTypeVal().equals(selectedRoomTO.getRoomType()))
		{
			selectedRoomBean.setRoomType(ROOM_TYPE.EXECUTIVE_PREMIUM);

		}
		
		
		
		
		
		
			if(ROOM_RESERVATION_TYPE.EARLY_MORNING.getroomResTypeVal().equals(selectedRoomTO.getReservationType()))
		{
			selectedRoomBean.setReservationType(ROOM_RESERVATION_TYPE.EARLY_MORNING);

		}
			else	if(ROOM_RESERVATION_TYPE.MORNING_NOON.getroomResTypeVal().equals(selectedRoomTO.getReservationType()))
			{
				selectedRoomBean.setReservationType(ROOM_RESERVATION_TYPE.MORNING_NOON);

			}
			else	if(ROOM_RESERVATION_TYPE.EVENING_NIGHT.getroomResTypeVal().equals(selectedRoomTO.getReservationType()))
			{
				selectedRoomBean.setReservationType(ROOM_RESERVATION_TYPE.EVENING_NIGHT);

			}
			
			
			
			if(ROOM_SIZE.SMALL.getRoomSizeVal().equals(selectedRoomTO.getRoomSize()))
			{
				selectedRoomBean.setRoomSize(ROOM_SIZE.SMALL);

			}
			else	if(ROOM_SIZE.MEDIUM.getRoomSizeVal().equals(selectedRoomTO.getRoomSize()))
			{
				selectedRoomBean.setRoomSize(ROOM_SIZE.MEDIUM);

			}
			else	if(ROOM_SIZE.FAMILY.getRoomSizeVal().equals(selectedRoomTO.getRoomSize()))
			{
				selectedRoomBean.setRoomSize(ROOM_SIZE.FAMILY);

			}
			else	if(ROOM_SIZE.DELUX.getRoomSizeVal().equals(selectedRoomTO.getRoomSize()))
			{
				selectedRoomBean.setRoomSize(ROOM_SIZE.DELUX);

			}
			
			DecisionPointVO decisionPointVO	= new DecisionPointVO();
			decisionPointVO.setSelectedRoomBean(selectedRoomBean);
			
		
		return this;
	}

	@Override
	 AbstractBuilder cloneDeep() {
		throw new UnsupportedOperationException("Cannot  cloneDeep().");
	}

	@Override
	DecisionPointVO build() {
		// TODO Auto-generated method stub
		return this.decisionPointVO;
	}

	@Override
	 AbstractBuilder fetchFromDB(RuleEngineHelperDAO ruleEngineHelperDAO) {
		
		
		
		decisionPointVO.setNumOfSuchRoomsAvailable(ruleEngineHelperDAO.getNumberOfAvailableRoomsByRoomAndSlot(decisionPointVO.getSelectedRoomBean().getRoomCatId(), decisionPointVO.getSelectedRoomBean().getSlotsId()));
		return this;
	}

	@Override
	 AbstractBuilder setToProduce(Object param) {
		// TODO Auto-generated method stub
		throw new UnsupportedOperationException("Cannot  setToProduce().");
	}

	
	
}
