package my.ruleengine;


import java.util.ArrayList;
import java.util.List;

 class PromotionDiscountRulesComposite extends RulesLayerComponent{

	List<RulesLayerComponent> layeringOfDiscountRelatedRules = new ArrayList<RulesLayerComponent>();

	@Override
	void add(RulesLayerComponent catalogComponent) {
		layeringOfDiscountRelatedRules.add(catalogComponent);
		
	}

	@Override
	public void accept(IRuleVisitor visitor) {
		throw new UnsupportedOperationException("Cannot accept().");
		
	}

	@Override
	boolean evaluate(DecisionPointVO decisionPointVO) {
		throw new UnsupportedOperationException("Cannot evaluate().");
	}

	@Override
	void print() {
		System.out.println("PromotionDiscountRulesComposite");
		
	}

	@Override
	List<RulesLayerComponent> getAllDisjointLayers() {
		// TODO Auto-generated method stub
		return this.layeringOfDiscountRelatedRules;
	}





	
	
	
}
