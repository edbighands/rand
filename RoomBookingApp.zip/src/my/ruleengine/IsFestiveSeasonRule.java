package my.ruleengine;

import java.util.Calendar;

class IsFestiveSeasonRule extends PromotionDiscountRulesComposite{


private static final Integer[] monthOfBookingInFestiveDate= {0,3,8,9,11};

	@Override
	void print() {
	
		System.out.println("IsFestiveSeasonRule");

	}

	@Override
	boolean evaluate(DecisionPointVO decisionPointVO) {
		 Calendar cal = Calendar.getInstance();
		int curMonth= cal.get(Calendar.MONTH);
		
		for(int i : monthOfBookingInFestiveDate)
		{
			if(i==curMonth)
				return true;
			
		}
		
		
		return false;
	}

	@Override
	public void accept(IRuleVisitor visitor) {
		visitor.visit(this);
		
	}



}
