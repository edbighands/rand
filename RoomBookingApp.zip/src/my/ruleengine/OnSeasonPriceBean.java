package my.ruleengine;

import java.math.BigDecimal;

class OnSeasonPriceBean extends AbstractPriceBean {

private static final BigDecimal FIXED_ON_SEASON_DISC= new BigDecimal("100.00");
	
	@Override
	protected BigDecimal getPrice() {
		this.price=	this.price.subtract(FIXED_ON_SEASON_DISC);
		return this.price;
	}

	@Override
	protected void setPrice(BigDecimal price) {
		this.price=price;

	}

}
