package my.controller;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;


import domain.models.UserRatingTran;
import domain.models.VRoomsDisplay;
import my.misc.beans.SelectedRoomTO;
import my.misc.beans.ViewBackingRoomAndRatingBean;
import my.service.CentralWaitingRoomService;
import my.utils.SpringAppContextGetter;

@Controller
public class RoomBookingController {

	@Autowired
	private CentralWaitingRoomService centralWaitingRoomService;

	@Autowired
	private WebApplicationContext webApplicationContext;

	@RequestMapping(value="/show.book")
	@ResponseBody
	public List<ViewBackingRoomAndRatingBean> showAllRoomsAndSlots()
	{

		List<VRoomsDisplay> rList=	centralWaitingRoomService.viewRoomsAndSlots();

		List<UserRatingTran> uRRatingList=	centralWaitingRoomService.viewRatingsOfRooms();
		List<ViewBackingRoomAndRatingBean> alViewBackingRoomAndRatingBean=	populationUtils(rList,uRRatingList);

		return alViewBackingRoomAndRatingBean;

	}

	
	@RequestMapping(value="/select.book")
	@ResponseBody
	public SelectedRoomTO selectRoomClick(HttpServletRequest req)
	{
		SelectedRoomTO selectedRoomTO=(SelectedRoomTO)SpringAppContextGetter.getBeanFromContextByName("selectedRoomTO");
		
		selectedRoomTO.setRoomCatId(	(Integer.parseInt((String)req.getAttribute("roomCatId"))));
		selectedRoomTO.setSlotsId(	(Integer.parseInt((String)req.getAttribute("slotsId"))));
		//similar setters on selectedRoomTO with values from the ajax call attributes from req
		selectedRoomTO=centralWaitingRoomService.roomSelectedNowFetchDynamicPrice(selectedRoomTO);
		
		return selectedRoomTO;
		
		
	}
	
	@RequestMapping(value="/confirm.book")
	@ResponseBody
	public String confirmRoomClick(HttpServletRequest req)
	{
		SelectedRoomTO selectedRoomTO=(SelectedRoomTO)req.getAttribute("SelectedRoomTO");
		
		int bookingID=centralWaitingRoomService.bookRoom(selectedRoomTO);
		
		return ""+bookingID;
		
		
	}
	
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity handleException(RuntimeException ex)
	{
			System.out.println(ex.getMessage());
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ex.getMessage());
		
	}
	
	
	
	
	private List<ViewBackingRoomAndRatingBean> populationUtils(List<VRoomsDisplay> rList,List<UserRatingTran> uRRatingList)
	{
		List<ViewBackingRoomAndRatingBean> alViewBackingRoomAndRatingBean= new 	ArrayList<ViewBackingRoomAndRatingBean>();
		for(VRoomsDisplay vRoomsDisplay : rList)
		{

			int roomID=vRoomsDisplay.getvRoomsForgedPK().getRoomCatId();



			for(UserRatingTran userRatingTran : uRRatingList)
			{

				if(roomID==userRatingTran.getId().getRoomCatId())
				{
					ViewBackingRoomAndRatingBean viewBackingRoomAndRatingBean=(ViewBackingRoomAndRatingBean)webApplicationContext.getBean("viewBackingRoomAndRatingBean");

					viewBackingRoomAndRatingBean.setAmenities(vRoomsDisplay.getAmenities());
					viewBackingRoomAndRatingBean.setIsDuplex(vRoomsDisplay.getIsDuplex());
					viewBackingRoomAndRatingBean.setIsHillView(vRoomsDisplay.getIsHillView());
					viewBackingRoomAndRatingBean.setIsSouthFacing(vRoomsDisplay.getIsSouthFacing());
					viewBackingRoomAndRatingBean.setPriceWithoutOffers(vRoomsDisplay.getPriceWithoutOffers());

					viewBackingRoomAndRatingBean.setReservationTime(vRoomsDisplay.getReservationTime());
					viewBackingRoomAndRatingBean.setReservationType(vRoomsDisplay.getReservationType());
					viewBackingRoomAndRatingBean.setRoomRating(userRatingTran.getRoomRating());
					viewBackingRoomAndRatingBean.setRoomSize(vRoomsDisplay.getRoomSize());
					viewBackingRoomAndRatingBean.setRoomType(vRoomsDisplay.getRoomType());

					viewBackingRoomAndRatingBean.setRoomCatId(roomID);
					viewBackingRoomAndRatingBean.setSlotsId(vRoomsDisplay.getvRoomsForgedPK().getSlotsId());

					alViewBackingRoomAndRatingBean.add(viewBackingRoomAndRatingBean);
				}

			}


		}


		return alViewBackingRoomAndRatingBean;


	}
	
	
	
	
	
	


}
