package my.misc.beans;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import domain.models.DmPricePromotion;
import my.DAO.RuleEngineHelperDAO;
import my.utils.SpringAppContextGetter;


public class PromotionMapHolder {


	
	private static final ConcurrentHashMap<Integer,BigDecimal> promoIDToPriceMap = new ConcurrentHashMap<Integer,BigDecimal>();
	
	public static synchronized BigDecimal refreshAndGet(Integer promoID)
	{
		RuleEngineHelperDAO ruleEngineHelperDAO=(RuleEngineHelperDAO)	SpringAppContextGetter.getBeanFromContextByName("ruleEngineHelperDAO");
		
		
		List<DmPricePromotion> promoList=	ruleEngineHelperDAO.getDmPricePromotionList();
		
		for(DmPricePromotion dmP : promoList )
		{
		
			promoIDToPriceMap.put(dmP.getId().getPromoId(), dmP.getPromoDisc());
			
		}
		
		return (promoIDToPriceMap.get(promoID)!=null)?promoIDToPriceMap.get(promoID):new BigDecimal("0.0");
	}
}
