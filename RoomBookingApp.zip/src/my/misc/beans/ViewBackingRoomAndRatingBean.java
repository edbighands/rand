package my.misc.beans;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigDecimal;



public class ViewBackingRoomAndRatingBean {


	private int roomRating;
	private int slotsId;

	private int roomCatId;

	private String amenities;

	private String isDuplex;

	private String isHillView;

	private String isSouthFacing;

	private BigDecimal priceWithoutOffers;

	private String reservationTime;

	private String reservationType;
	private String roomSize;

	private String roomType;

	public String getAmenities() {
		return amenities;
	}

	public void setAmenities(String amenities) {
		this.amenities = amenities;
	}

	public String getIsDuplex() {
		return isDuplex;
	}

	public void setIsDuplex(String isDuplex) {
		this.isDuplex = isDuplex;
	}

	public String getIsHillView() {
		return isHillView;
	}

	public void setIsHillView(String isHillView) {
		this.isHillView = isHillView;
	}

	public String getIsSouthFacing() {
		return isSouthFacing;
	}

	public void setIsSouthFacing(String isSouthFacing) {
		this.isSouthFacing = isSouthFacing;
	}

	public BigDecimal getPriceWithoutOffers() {
		return priceWithoutOffers;
	}

	public void setPriceWithoutOffers(BigDecimal priceWithoutOffers) {
		this.priceWithoutOffers = priceWithoutOffers;
	}

	public String getReservationTime() {
		return reservationTime;
	}

	public void setReservationTime(String reservationTime) {
		this.reservationTime = reservationTime;
	}

	public String getReservationType() {
		return reservationType;
	}

	public void setReservationType(String reservationType) {
		this.reservationType = reservationType;
	}

	public String getRoomSize() {
		return roomSize;
	}

	public void setRoomSize(String roomSize) {
		this.roomSize = roomSize;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public int getRoomRating() {
		return roomRating;
	}

	public void setRoomRating(int roomRating) {
		this.roomRating = roomRating;
	}

	public int getSlotsId() {
		return slotsId;
	}

	public void setSlotsId(int slotsId) {
		this.slotsId = slotsId;
	}

	public int getRoomCatId() {
		return roomCatId;
	}

	public void setRoomCatId(int roomCatId) {
		this.roomCatId = roomCatId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + roomCatId;
		result = prime * result + slotsId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof ViewBackingRoomAndRatingBean)) {
			return false;
		}
		ViewBackingRoomAndRatingBean other = (ViewBackingRoomAndRatingBean) obj;
		if (roomCatId != other.roomCatId) {
			return false;
		}
		if (slotsId != other.slotsId) {
			return false;
		}
		return true;
	}


public	static class JavaBeanCopier {

		public static Object copy(Object fromBean) {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			XMLEncoder out = new XMLEncoder(bos);
			out.writeObject(fromBean);
			out.close();
			ByteArrayInputStream bis = new
					ByteArrayInputStream(bos.toByteArray());
			XMLDecoder in = new XMLDecoder(bis);
			Object toBean = in.readObject();
			in.close();
			try {
				bos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return toBean;
		}

	}


}





 