package my.DAO;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import domain.models.UserRatingTran;
import domain.models.Userinfo;
import domain.models.VRoomsDisplay;

@Repository
public class ViewableElementsReadOnlyDAO {

	

	@PersistenceContext
	private EntityManager entityManager;
	

	
	
	public List<Userinfo> getUserinfoList()	{

		TypedQuery<Userinfo> query = entityManager.createNamedQuery("Userinfo.findAll", Userinfo.class);

		return query.getResultList();


	}

	public List<UserRatingTran> getUserRatingTranList()	{

		TypedQuery<UserRatingTran> query = entityManager.createNamedQuery("UserRatingTran.findAll", UserRatingTran.class);

		return query.getResultList();


	}

	public List<VRoomsDisplay> getVRoomsDisplayList()	{

		TypedQuery<VRoomsDisplay> query = entityManager.createNamedQuery("VRoomsDisplay.findAll", VRoomsDisplay.class);

		return query.getResultList();


	}

	
}
