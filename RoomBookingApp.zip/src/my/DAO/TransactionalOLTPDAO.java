package my.DAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import domain.models.RoomReservationOltp;
import domain.models.RoomSlotAvlbltyLkp;
import domain.models.RoomSlotAvlbltyLkpPK;
import my.misc.beans.SelectedRoomTO;

@Repository
public class TransactionalOLTPDAO {

	


	@PersistenceContext
	private EntityManager entityManager;
	
	
	public void confirmReservation(RoomReservationOltp roomReservationOltp)
	{
		
		entityManager.persist(roomReservationOltp);
		
		
	}
	public RoomSlotAvlbltyLkp changeAvailability(RoomSlotAvlbltyLkp roomSlotAvlbltyLkp)
	{
		
		roomSlotAvlbltyLkp =entityManager.merge(roomSlotAvlbltyLkp);
		
		return roomSlotAvlbltyLkp;
	}
	
	
	public RoomSlotAvlbltyLkp lookForAvailability(SelectedRoomTO selectedRoomTO)
	{
		RoomSlotAvlbltyLkpPK roomSlotAvlbltyLkpPK	 = new RoomSlotAvlbltyLkpPK();
		roomSlotAvlbltyLkpPK.setRoomCatId(selectedRoomTO.getRoomCatId());
		roomSlotAvlbltyLkpPK.setSlotId(selectedRoomTO.getSlotsId());
				 RoomSlotAvlbltyLkp roomSlotAvlbltyLkp	=	entityManager.find(RoomSlotAvlbltyLkp.class, roomSlotAvlbltyLkpPK);
		return roomSlotAvlbltyLkp;
		
	}
	
	public void refreshAfterOLE(RoomSlotAvlbltyLkp roomSlotAvlbltyLkp)
	{
		
		entityManager.refresh(roomSlotAvlbltyLkp);
	}
	
	public void detachhEntityForCleaningL1(RoomSlotAvlbltyLkp roomSlotAvlbltyLkp)
	{
		
		entityManager.detach(roomSlotAvlbltyLkp);
	}
	
}
