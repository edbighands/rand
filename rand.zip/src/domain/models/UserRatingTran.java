package domain.models;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the USER_RATING_TRANS database table.
 * 
 */
@Entity
@Table(name="USER_RATING_TRANS")
@NamedQuery(name="UserRatingTran.findAll", query="SELECT u FROM UserRatingTran u")
public class UserRatingTran implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private UserRatingTranPK id;

	@Column(name="ROOM_RATING")
	private int roomRating;

	public UserRatingTran() {
	}

	public UserRatingTranPK getId() {
		return this.id;
	}

	public void setId(UserRatingTranPK id) {
		this.id = id;
	}

	public int getRoomRating() {
		return this.roomRating;
	}

	public void setRoomRating(int roomRating) {
		this.roomRating = roomRating;
	}

}