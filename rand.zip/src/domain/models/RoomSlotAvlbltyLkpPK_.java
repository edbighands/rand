package domain.models;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-08T02:28:55.492-0700")
@StaticMetamodel(RoomSlotAvlbltyLkpPK.class)
public class RoomSlotAvlbltyLkpPK_ {
	public static volatile SingularAttribute<RoomSlotAvlbltyLkpPK, Integer> roomCatId;
	public static volatile SingularAttribute<RoomSlotAvlbltyLkpPK, Integer> slotId;
}
