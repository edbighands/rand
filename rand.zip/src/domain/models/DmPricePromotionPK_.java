package domain.models;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-08T22:56:14.446-0700")
@StaticMetamodel(DmPricePromotionPK.class)
public class DmPricePromotionPK_ {
	public static volatile SingularAttribute<DmPricePromotionPK, Integer> promoId;
	public static volatile SingularAttribute<DmPricePromotionPK, Integer> roomPromoId;
}
