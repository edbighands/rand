package domain.models;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-08T04:05:24.330-0700")
@StaticMetamodel(RoomSlotAvlbltyLkp.class)
public class RoomSlotAvlbltyLkp_ {
	public static volatile SingularAttribute<RoomSlotAvlbltyLkp, RoomSlotAvlbltyLkpPK> id;
	public static volatile SingularAttribute<RoomSlotAvlbltyLkp, Integer> availabilityCount;
	public static volatile SingularAttribute<RoomSlotAvlbltyLkp, Long> versionId;
}
