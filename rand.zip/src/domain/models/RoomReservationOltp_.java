package domain.models;

import java.math.BigDecimal;
import java.sql.Timestamp;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-08T02:28:55.358-0700")
@StaticMetamodel(RoomReservationOltp.class)
public class RoomReservationOltp_ {
	public static volatile SingularAttribute<RoomReservationOltp, Integer> reservationId;
	public static volatile SingularAttribute<RoomReservationOltp, BigDecimal> finalPrice;
	public static volatile SingularAttribute<RoomReservationOltp, String> promoApplied;
	public static volatile SingularAttribute<RoomReservationOltp, Timestamp> reservationDate;
	public static volatile SingularAttribute<RoomReservationOltp, Integer> roomCatId;
	public static volatile SingularAttribute<RoomReservationOltp, Integer> slotsId;
	public static volatile SingularAttribute<RoomReservationOltp, Integer> userId;
}
