package domain.models;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the USER_RATING_TRANS database table.
 * 
 */
@Embeddable
public class UserRatingTranPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="USER_ID")
	private int userId;

	@Column(name="ROOM_CAT_ID")
	private int roomCatId;

	public UserRatingTranPK() {
	}
	public int getUserId() {
		return this.userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getRoomCatId() {
		return this.roomCatId;
	}
	public void setRoomCatId(int roomCatId) {
		this.roomCatId = roomCatId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof UserRatingTranPK)) {
			return false;
		}
		UserRatingTranPK castOther = (UserRatingTranPK)other;
		return 
			(this.userId == castOther.userId)
			&& (this.roomCatId == castOther.roomCatId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userId;
		hash = hash * prime + this.roomCatId;
		
		return hash;
	}
}