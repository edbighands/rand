package domain.models;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-08T04:14:25.497-0700")
@StaticMetamodel(Userinfo.class)
public class Userinfo_ {
	public static volatile SingularAttribute<Userinfo, Integer> userId;
	public static volatile SingularAttribute<Userinfo, String> password;
}
