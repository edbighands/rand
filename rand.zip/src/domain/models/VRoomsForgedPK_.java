package domain.models;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-09T07:14:48.574-0700")
@StaticMetamodel(VRoomsForgedPK.class)
public class VRoomsForgedPK_ {
	public static volatile SingularAttribute<VRoomsForgedPK, Integer> roomCatId;
	public static volatile SingularAttribute<VRoomsForgedPK, Integer> slotsId;
}
