package domain.models;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class VRoomsForgedPK implements Serializable{

	private static final long serialVersionUID = 1L;


	@Column(name="SLOTS_ID", insertable=false, updatable=false)
	private int slotsId;
	@Column(name="ROOM_CAT_ID", insertable=false, updatable=false)
	private int roomCatId;

	

	public VRoomsForgedPK() {
	
	}



	public int getSlotsId() {
		return slotsId;
	}



	public void setSlotsId(int slotsId) {
		this.slotsId = slotsId;
	}



	public int getRoomCatId() {
		return roomCatId;
	}



	public void setRoomCatId(int roomCatId) {
		this.roomCatId = roomCatId;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + roomCatId;
		result = prime * result + slotsId;
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof VRoomsForgedPK)) {
			return false;
		}
		VRoomsForgedPK other = (VRoomsForgedPK) obj;
		if (roomCatId != other.roomCatId) {
			return false;
		}
		if (slotsId != other.slotsId) {
			return false;
		}
		return true;
	}


}
