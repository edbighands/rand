package domain.models;

import java.math.BigDecimal;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-08T22:56:14.931-0700")
@StaticMetamodel(DmPricePromotion.class)
public class DmPricePromotion_ {
	public static volatile SingularAttribute<DmPricePromotion, DmPricePromotionPK> id;
	public static volatile SingularAttribute<DmPricePromotion, String> promoCategory;
	public static volatile SingularAttribute<DmPricePromotion, BigDecimal> promoDisc;
}
