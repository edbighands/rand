package domain.models;

import java.math.BigDecimal;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2018-09-09T07:15:51.886-0700")
@StaticMetamodel(VRoomsDisplay.class)
public class VRoomsDisplay_ {
	public static volatile SingularAttribute<VRoomsDisplay, String> amenities;
	public static volatile SingularAttribute<VRoomsDisplay, String> isDuplex;
	public static volatile SingularAttribute<VRoomsDisplay, String> isHillView;
	public static volatile SingularAttribute<VRoomsDisplay, String> isSouthFacing;
	public static volatile SingularAttribute<VRoomsDisplay, BigDecimal> priceWithoutOffers;
	public static volatile SingularAttribute<VRoomsDisplay, String> reservationTime;
	public static volatile SingularAttribute<VRoomsDisplay, String> reservationType;
	public static volatile SingularAttribute<VRoomsDisplay, String> roomSize;
	public static volatile SingularAttribute<VRoomsDisplay, String> roomType;
	public static volatile SingularAttribute<VRoomsDisplay, VRoomsForgedPK> vRoomsForgedPK;
}
