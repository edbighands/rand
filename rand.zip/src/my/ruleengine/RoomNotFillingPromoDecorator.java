package my.ruleengine;

import java.math.BigDecimal;

class RoomNotFillingPromoDecorator extends PricePromoDecorator {

	private BigDecimal roomNotFilingPromoDisc;
	
	@Override
	protected BigDecimal getPrice() {
		return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.roomNotFilingPromoDisc);
	}

	BigDecimal getSmallRoomPromoDisc() {
		return roomNotFilingPromoDisc;
	}

	void setSmallRoomPromoDisc(BigDecimal roomNotFilingPromoDisc) {
		this.roomNotFilingPromoDisc = roomNotFilingPromoDisc;
	}

	RoomNotFillingPromoDecorator() {
		
	}

	RoomNotFillingPromoDecorator(AbstractPriceBean priceBean) {
	this();
	
	
	this.baseSpecialPriceDecoretee=priceBean;
	}
	
	
}

