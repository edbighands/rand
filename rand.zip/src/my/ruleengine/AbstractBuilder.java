package my.ruleengine;

import javax.sql.DataSource;

import my.DAO.RuleEngineHelperDAO;

public abstract class AbstractBuilder {

	public abstract  AbstractBuilder create();
	public abstract  AbstractBuilder cloneDeep();
	public abstract   Object build();
	public abstract  AbstractBuilder fetchFromDB(RuleEngineHelperDAO RuleEngineHelperDAO);
	public abstract  AbstractBuilder setToProduce(Object param);
}
