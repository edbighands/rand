package my.ruleengine;

import java.math.BigDecimal;

class PremiumRoomPromoDecorator extends PricePromoDecorator {

	private BigDecimal premiumPromoDisc;
	
	@Override
	protected BigDecimal getPrice() {
		return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.premiumPromoDisc);
	}

	BigDecimal getPremiumPromoDisc() {
		return premiumPromoDisc;
	}

	void setPremiumPromoDisc(BigDecimal premiumPromoDisc) {
		this.premiumPromoDisc = premiumPromoDisc;
	}

	PremiumRoomPromoDecorator() {
		
	}


	PremiumRoomPromoDecorator(AbstractPriceBean priceBean) {
this();
		
		
		this.baseSpecialPriceDecoretee=priceBean;
	}	
	
	
}
