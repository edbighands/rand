package my.ruleengine;

import java.math.BigDecimal;



final class SelectedRoomBean {

	 static enum ROOM_TYPE{
		
		ECONOMY("economy"), STANDARD("standard"), CORPORATE("corporate"), EXECUTIVE_PREMIUM("executivePremium");
		private String roomTypeVal;
		private ROOM_TYPE (String roomTypeVal)
		{this.roomTypeVal=roomTypeVal;}
		public String getRoomTypeVal()
		{
			return this.roomTypeVal;
		}
	} 
	
	 static enum ROOM_SIZE{
		
		SMALL("small"), MEDIUM("medium"), FAMILY("family"), DELUX("delux");
		private String roomSizeVal;
		private ROOM_SIZE (String roomSizeVal)
		{this.roomSizeVal=roomSizeVal;}
		public String getRoomTypeVal()
		{
			return this.roomSizeVal;
		}
	} 
	
	
	 static enum ROOM_RESERVATION_TYPE{
		
		EARLY_MORNING("earlyMorning"), MORNING_NOON("morningNoon"), EVENING_NIGHT("eveningNight");
		private String roomResTypeVal;
		private ROOM_RESERVATION_TYPE (String roomResTypeVal)
		{this.roomResTypeVal=roomResTypeVal;}
		public String getRoomTypeVal()
		{
			return this.roomResTypeVal;
		}
	}
	
	private String isDuplex;

	
	private String isHillView;


	private String isSouthFacing;


	private BigDecimal priceWithoutOffers;





	private ROOM_RESERVATION_TYPE reservationType;


	private ROOM_SIZE roomSize;


	private ROOM_TYPE roomType;

	
	private Integer slotsId;
	private Integer roomCatId;

	 String getIsDuplex() {
		return isDuplex;
	}


	 void setIsDuplex(String isDuplex) {
		this.isDuplex = isDuplex;
	}


	 String getIsHillView() {
		return isHillView;
	}


	 void setIsHillView(String isHillView) {
		this.isHillView = isHillView;
	}


	 String getIsSouthFacing() {
		return isSouthFacing;
	}


	 void setIsSouthFacing(String isSouthFacing) {
		this.isSouthFacing = isSouthFacing;
	}


	 BigDecimal getPriceWithoutOffers() {
		return priceWithoutOffers;
	}


	 void setPriceWithoutOffers(BigDecimal priceWithoutOffers) {
		this.priceWithoutOffers = priceWithoutOffers;
	}


	 ROOM_RESERVATION_TYPE getReservationType() {
		return reservationType;
	}


	 void setReservationType(ROOM_RESERVATION_TYPE reservationType) {
		this.reservationType = reservationType;
	}


	 ROOM_SIZE getRoomSize() {
		return roomSize;
	}


	 void setRoomSize(ROOM_SIZE roomSize) {
		this.roomSize = roomSize;
	}


	 ROOM_TYPE getRoomType() {
		return roomType;
	}


	public void setRoomType(ROOM_TYPE roomType) {
		this.roomType = roomType;
	}


	public Integer getSlotsId() {
		return slotsId;
	}


	public void setSlotsId(Integer slotsId) {
		this.slotsId = slotsId;
	}


	public Integer getRoomCatId() {
		return roomCatId;
	}


	public void setRoomCatId(Integer roomCatId) {
		this.roomCatId = roomCatId;
	}
	
	


}
