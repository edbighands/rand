package my.ruleengine;

import javax.sql.DataSource;

import my.DAO.RuleEngineHelperDAO;

public class ConcreteDecisionPointVOBuilder extends AbstractBuilder{

	private DecisionPointVO decisionPointVO;
	
	@Override
	public AbstractBuilder create() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AbstractBuilder cloneDeep() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object build() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AbstractBuilder fetchFromDB(RuleEngineHelperDAO ruleEngineHelperDAO) {
		
		
		ruleEngineHelperDAO.getNumberOfAvailableRoomsByRoomAndSlot(decisionPointVO.getSelectedRoomBean().getRoomCatId(), decisionPointVO.getSelectedRoomBean().getSlotsId());
		
		return null;
	}

	@Override
	public AbstractBuilder setToProduce(Object param) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
