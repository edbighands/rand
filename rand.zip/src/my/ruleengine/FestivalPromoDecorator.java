package my.ruleengine;

import java.math.BigDecimal;

class FestivalPromoDecorator extends PricePromoDecorator {

	private BigDecimal festivalDiscount;
	
	 BigDecimal getFestivalDiscount() {
		return festivalDiscount;
	}

	 void setFestivalDiscount(BigDecimal festivalDiscount) {
		this.festivalDiscount = festivalDiscount;
	}
	 
	 

	FestivalPromoDecorator(AbstractPriceBean priceBean) {
		this();
		
		
		this.baseSpecialPriceDecoretee=priceBean;
	}

	public FestivalPromoDecorator() {
		
	}

	@Override
	protected BigDecimal getPrice() {
	return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.festivalDiscount);
	}

}
