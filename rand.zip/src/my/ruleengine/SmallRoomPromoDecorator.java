package my.ruleengine;

import java.math.BigDecimal;

class SmallRoomPromoDecorator extends PricePromoDecorator {

	private BigDecimal smallRoomPromoDisc;
	
	@Override
	protected BigDecimal getPrice() {
		return	this.baseSpecialPriceDecoretee.getPrice().subtract(this.smallRoomPromoDisc);
	}

	BigDecimal getSmallRoomPromoDisc() {
		return smallRoomPromoDisc;
	}

	void setSmallRoomPromoDisc(BigDecimal smallRoomPromoDisc) {
		this.smallRoomPromoDisc = smallRoomPromoDisc;
	}

	SmallRoomPromoDecorator() {
		
	}

SmallRoomPromoDecorator(AbstractPriceBean priceBean) {
	this();
	
	
	this.baseSpecialPriceDecoretee=priceBean;
	}
	
	
}
