package my.ruleengine;

import java.util.Calendar;

import javax.sql.DataSource;

import my.DAO.RuleEngineHelperDAO;

public class ConcretePriceBeanBuilder extends AbstractBuilder {

	private AbstractPriceBean abstractPriceBean;
	@Override
	public AbstractBuilder create() {
		
		 Calendar cal = Calendar.getInstance();
			int curMonth= cal.get(Calendar.MONTH);
			boolean isOffSeason=false;
			switch (curMonth)
			{
			
			case 0 : isOffSeason=false; break;
			case 1: isOffSeason=true;break;
			case 2:isOffSeason=true;break;
			case 3: isOffSeason=false;break;
			case 4: isOffSeason=true;break;
			case 5: isOffSeason=true;break;
			case 6: isOffSeason=true;break;
			case 7: isOffSeason=true;break;
			case 8: isOffSeason=true;break;
			case 9: isOffSeason=false;break;
			case 10: isOffSeason=true;break;
			case 11: isOffSeason=false;break;
			
			}
			
			if(isOffSeason)
			{
				this.abstractPriceBean= new OffSeasonPriceBean();
				
			}
			else
			{
				this.abstractPriceBean= new OnSeasonPriceBean();
				
			}
		
		return this;
	}

	@Override
	public AbstractBuilder cloneDeep() {
		throw new UnsupportedOperationException("Cannot  cloneDeep().");
	}

	@Override
	public Object build() {
		// TODO Auto-generated method stub
		return this.abstractPriceBean;
	}

	@Override
	public AbstractBuilder fetchFromDB(RuleEngineHelperDAO ruleEngineHelperDAO) {
		throw new UnsupportedOperationException("Cannot  fetchFromDB().");
	}

	@Override
	public AbstractBuilder setToProduce(Object param) {
		SelectedRoomBean selectedRoomBean = (SelectedRoomBean)param;
		this.abstractPriceBean.setPrice(selectedRoomBean.getPriceWithoutOffers());
		return this;
	}
	
	
}
