package my.ruleengine;

 class DecisionPointVO {

	 private SelectedRoomBean selectedRoomBean;
	 private Integer numOfSuchRoomsAvailable;
	
	 SelectedRoomBean getSelectedRoomBean() {
		return selectedRoomBean;
	}
	void setSelectedRoomBean(SelectedRoomBean selectedRoomBean) {
		this.selectedRoomBean = selectedRoomBean;
	}
	Integer getNumOfSuchRoomsAvailable() {
		return numOfSuchRoomsAvailable;
	}
	void setNumOfSuchRoomsAvailable(Integer numOfSuchRoomsAvailable) {
		this.numOfSuchRoomsAvailable = numOfSuchRoomsAvailable;
	}
	 
	 
}
