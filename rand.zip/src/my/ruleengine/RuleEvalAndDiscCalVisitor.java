package my.ruleengine;

class RuleEvalAndDiscCalVisitor implements IRuleVisitor {

	private DecisionPointVO decisionPointVO;
	private AbstractPriceBean abstractPriceBean;
	
	
	
	
	RuleEvalAndDiscCalVisitor(DecisionPointVO decisionPointVO,AbstractPriceBean abstractPriceBean) {
		
		this.decisionPointVO = decisionPointVO;
		this.abstractPriceBean=abstractPriceBean;
	}




	
	
	
	//method capture by overload
	
	private void visit(IsNotSellingEnoughRule rule)
	{
		if(rule.evaluate(decisionPointVO))
		{
			abstractPriceBean=new RoomNotFillingPromoDecorator(abstractPriceBean);
		}
		
	}
	 private void visit(IsPremiumRoomRule rule)
	{
		 if(rule.evaluate(decisionPointVO))
		 {
				abstractPriceBean=new PremiumRoomPromoDecorator(abstractPriceBean);
			} 
	}
	private void visit(IsSmallRoomRule rule)
	{
		 if(rule.evaluate(decisionPointVO))
		 {
			 abstractPriceBean=new SmallRoomPromoDecorator(abstractPriceBean);
		 }
	}

	private void visit(IsFestiveSeasonRule rule)
	{
		 if(rule.evaluate(decisionPointVO))
		 {
			 abstractPriceBean=new FestivalPromoDecorator(abstractPriceBean);
		 }
	}





	@Override
	public void visit(RulesLayerComponent rule) {
		
		if(rule instanceof IsNotSellingEnoughRule)
			visit((IsNotSellingEnoughRule) rule);
		else if (rule instanceof IsPremiumRoomRule)
			visit((IsPremiumRoomRule) rule);
		else if (rule instanceof IsSmallRoomRule)
			visit((IsSmallRoomRule) rule);
		else if (rule instanceof IsFestiveSeasonRule)
			visit((IsFestiveSeasonRule) rule);
	}







	AbstractPriceBean getAbstractPriceBean() {
		return abstractPriceBean;
	}
	

}
