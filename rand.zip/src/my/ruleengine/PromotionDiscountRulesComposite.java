package my.ruleengine;


import java.util.ArrayList;
import java.util.List;

abstract class PromotionDiscountRulesComposite extends RulesLayerComponent{

	List<RulesLayerComponent> layeringOfDiscountRelatedRules = new ArrayList<RulesLayerComponent>();

	@Override
	void add(RulesLayerComponent catalogComponent) {
		layeringOfDiscountRelatedRules.add(catalogComponent);
		
	}





	
	
	
}
